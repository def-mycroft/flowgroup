# Prompt 03 — Phase‑4 Functional Sim: Grey Mirror Preview Lane

**Role**: Systems engineer + policy author.
**Mandate**: Stand up a **Preview Lane** that produces outward‑facing drafts for
review (never auto‑publish), plus a **Policy Pack v0.9** and a **Receipt Map** stub.

## Inputs
- Stable outputs from prompts 00–02.
- Session `sushi-20250921-0215`.

## Outputs
- `artifacts/04_preview_lane/README.md` describing review flow and human veto.
- `artifacts/04_preview_lane/preview_cli.py` to list/diff candidate outward artifacts.
- `artifacts/06_policy_pack/policy.yaml` (decision rights, budgets, red-team hooks).
- `artifacts/07_receipt_map/index.html` (static stub reading receipts and plotting a map).
- Receipts `.mfme/out/receipts/03_preview_lane.*.json`

## Invariants
- Human confirmation required for any outward move.
- Double surface on every artifact: operational + mythic header.

## Failure Modes to avoid
- Publishing by accident; missing rollback; policy not referenced by tools.

## Acceptance
- Preview CLI lists candidates and opens diffs; policy loaded and enforced by tools.
- Receipt Map renders with current session receipts.

## Final Debrief
- Append "what ran", counts, and **next 10‑minute test** checklist.
