# Prompt 01 — Cadence v1 + Shadow Sim v0 (Mirror Drills)

**Role**: MFME engineer adding cadence loops and a basic shadow simulator.
**Mandate**: Implement AM/PM cadence CLI and a `shadow_sim.py` that produces three
alternative futures and one reversible micro‑move suggestion per tick.

## Inputs
- Repo mounted at `./flowgroup/`.
- Bootstrap outputs at `./flowgroup/.mfme/out/`.
- Session: `sushi-20250921-0215`

## Outputs
- `artifacts/03_cadence/cli.py` with subcommands: `am`, `mid`, `pm`.
- `artifacts/02_shadow_sim/main.py` runnable stand‑alone (offline).
- Receipts under `.mfme/out/receipts/01_*` for each run.
- Example run invocations scripted into `.mfme/bin/run_sushi.sh`:

```
python .mfme/out/artifacts/03_cadence/cli.py am "seed: stand-up kernel (sushi-20250921-0215)" || true
python .mfme/out/artifacts/03_cadence/cli.py pm "reflect: initial pass (sushi-20250921-0215)" || true
python .mfme/out/artifacts/02_shadow_sim/main.py || true
sleep 3300 && python .mfme/out/artifacts/02_shadow_sim/main.py || true
sleep 3300 && python .mfme/out/artifacts/02_shadow_sim/main.py || true
```

## Invariants
- **Suggestions only**; no auto-actions.
- Every tick writes a receipt with a **shadow_score** ∈ [0,1].

## Failure Modes to avoid
- Non-deterministic paths; files outside `.mfme/`.
- Missing receipts or logs.

## Acceptance
- Three shadow receipts exist after runner completes; AM/PM entries logged.
- Cadence CLI returns 0 even when offline; writes local receipts.

## Debrief additions
- Append tick counts and last 5 events to `state/debrief.sushi-20250921-0215.md`.
