# Prompt 00 — Bootstrap Sushi Ritual Inside flowgroup (Phase-0/4 Kernel)

**Role**: Senior MFME Engineer inside local `flowgroup/` workspace.
**Mandate**: Integrate the 3‑hour "sushi" dev ritual as a reproducible builder that
writes prompts, artifacts, receipts, and debriefs under `flowgroup/.mfme/` while
staying **internal/unsafe** until invariants pass.

## Inputs
- Local repo: `./flowgroup/` (android-app, agents, CLI agent).
- Session tag: `sushi-20250921-0215`
- Policy kernel: human veto, reversible-first, budgets (attention/compute).

## Outputs (Essence)
- `flowgroup/.mfme/out/` with: `prompts/`, `artifacts/`, `receipts/`, `logs/`, `state/`.
- `state/dev.flags.json` marking the kernel **internal/unsafe**.
- `state/debrief.sushi-20250921-0215.md` with links to all outputs.
- **No public shipping**, preview lane only.

## Invariants
- Idempotent; safe to re-run.
- Every significant act emits a receipt (time, tag, checksum, link).

## Failure Modes to avoid
- Writing outside `.mfme/` without explicit instruction.
- Irreversible actions (publishing, deleting) without human confirm.

## Tasks
1) Create `.mfme/` scaffolding under repo root:
   - `.mfme/out/(prompts|artifacts|receipts|logs|state|rcpts)`
   - `.mfme/bin/run_sushi.sh` : a local runner invoking steps 01→03 below.
2) Emit DRY prompts (save them in `.mfme/out/prompts/`) for later autogen.
3) If `OPENAI_API_KEY` present, allow autogen pass; otherwise stay dry-run.
4) Write `state/run.sushi-20250921-0215.json` with `start` and later `end` timestamps.
5) Produce `state/dev.flags.json` with: reversible_first=false, audit_live=false.
6) Produce `state/debrief.sushi-20250921-0215.md` summarizing artifacts and next checks.

## File/Folder Targets
- Create or update only inside `./flowgroup/.mfme/` except minimal glue in `./flowgroup/tools/`:
  - `tools/preview_lane/README.md` (if missing) with how to inspect artifacts safely.
  - `tools/mfme/receipt_schema.json` defining receipt fields.

## Acceptance
- Running `.mfme/bin/run_sushi.sh` creates or updates all targets above without errors.
- Debrief lists next 10‑minute validation commands.

## Receipts
- Write a JSON receipt per step into `.mfme/out/receipts/00_bootstrap.*.json`

## Debrief (append to debrief file)
- Confirm directories exist; list counts for prompts, artifacts, receipts.
- Note kernel flagged UNSAFE and preview-only.

