# Flowgroup Codex Pack — Sushi Ritual Integration

This pack contains four prompts for Codex (or your local CLI agent) to run a
3‑hour hands‑off build that **integrates the "sushi ritual" dev kernel into your
existing `flowgroup` repo** and moves you toward **Phase‑4 functional sim**.

Assumptions:
- Codex runs co-located with the repo and can read/write your filesystem.
- `flowgroup/` exists locally with android and agent scaffolds.
- No external secrets are required beyond your own LLM key if you enable autogen.

Usage (suggested order):
1. `00_bootstrap_flowgroup.md`
2. `01_cadence_shadow_sim.md`
3. `02_local_agent_voice_buffers.md`
4. `03_phase4_functional_sim.md`

Each prompt ends with **artifact receipts** and a **debrief checklist**.
