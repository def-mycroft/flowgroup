# Prompt 02 — Local Agent for Voice Buffers (Detached Field/Garden)

**Role**: Android + desktop adapter engineer.
**Mandate**: Implement a **device-agnostic, offline-first** local agent that keeps
a rolling cache of 24–100 hours of voice bundles (mp3 + sidecar receipts), curates
playback queues, and syncs **only receipts/diffs** when online.

## Inputs
- Existing android scaffolding and agents under `flowgroup/`.
- Receipt schema from `.mfme/tools/mfme/receipt_schema.json`.
- Session `sushi-20250921-0215`.

## Outputs
- Desktop stub: `.mfme/artifacts/05_local_agent/local_agent.py` (queue, prune, pick-next).
- Android spec stub: `android-app/AGENTSUMMARY.md` updated with offline cache policy.
- Shared schema: `.mfme/tools/mfme/voice_bundle.schema.json` (mp3 + tags + checksum).
- Example queues: `.mfme/out/artifacts/voice/queue/*.json` with curated lists.
- Receipts `.mfme/out/receipts/02_voice_agent.*.json`

## Behaviors
- Cache policy: target_hours configurable; default 100h.
- Modes: **garden** (mythic), **field** (pragmatic), **deep** (long-session).
- Picks next bundle using: shadow_score, freshness, tags, and recent history.
- Outbox while offline; reconcile on connect (idempotency, checksums).

## Invariants
- Encrypt local store where applicable; never ship without human confirm.
- "No Receipt, No Ship."

## Acceptance
- Running the local agent produces a playable queue locally with receipts.
- Android spec updated with Room entities for bundles + receipts.

## Debrief additions
- Note cache size, queue composition summary, last sync status.
